import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ResourceManagerComponent } from './resource-manager/resource-manager.component';
import { ResourceComponent } from './resource-manager/resource.component';
import { TimelineComponent } from './resource-manager/timeline.component';


@NgModule({
  declarations: [
    AppComponent,
    ResourceManagerComponent,
    ResourceComponent,
    TimelineComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

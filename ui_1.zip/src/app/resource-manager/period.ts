export class Period {
    start: Date;
    end: Date;
    constructor(daysFromNow: number) {
        this.start = Date.now;
        this.end = this.start.setDate(this.start.getDate() + daysFromNow);
    }

    Days() {
        return [1, 2, 3];
    }
}

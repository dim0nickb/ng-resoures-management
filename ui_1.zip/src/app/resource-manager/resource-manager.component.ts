import { Component, OnInit, Input } from '@angular/core';
import { ResourceComponent } from './resource.component';
import { TimelineComponent } from './timeline.component';
import { Resource } from './resource';
import { MOCK_RESOURCES } from './resources';
import { Period } from './period';


@Component({
  selector: 'resource-manager',
  template: `
    <div class="flex-container container">
      <div id="resources" class="flex-item-1 container">
        <resource *ngFor="let resource of resources;" [resource] = "resource"></resource>
      </div>
      <div id="timelines" class="flex-item-3 container">
        <timeline 
          *ngFor="let resource of resources;" 
          [resource] = "resource" 
          [period]={{this.period}}>
        </timeline>
      </div>
    </div>
  `,
  styles: [
    '.container { border: 1px solid #aaa; }',
    '.flex-container { display:flex; }',
    '.flex-item-1 { flex: 1; }',
    '.flex-item-3 { flex: 3; }'
  ]
})
export class ResourceManagerComponent implements OnInit {

  @Input() shownDays: number;

  period: Period;
  resources: Resource[] = MOCK_RESOURCES;
  timelines: TimelineComponent[] = [];

  constructor() {  }

  ngOnInit() {
    this.period = new Period(this.shownDays);
  }

}

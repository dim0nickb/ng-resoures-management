import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'resource',
  template: `
    <div>
      {{ this.name }}
    </div>
  `,
  styles: []
})
export class ResourceComponent implements OnInit {

  @Input() name: string;
  constructor() { }

  ngOnInit() {
  }

}

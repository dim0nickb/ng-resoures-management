import { Resource } from './resource';

export const MOCK_RESOURCES: Resource[] = [
    new Resource('1', 'Андрей'),
    new Resource('2', 'Степан'),
    new Resource('3', 'Роман'),
    new Resource('4', 'Ольга'),
];

import { Component, OnInit, Input } from '@angular/core';
import { Period } from './period';

@Component({
  selector: 'timeline',
  template: `
    <div>
      <div *ngFor="let day of period.Days()">"day"</div>
    </div>
  `,
  styles: []
})
export class TimelineComponent implements OnInit {

  @Input() period: Period;

  constructor() { }

  ngOnInit() {
  }

}
